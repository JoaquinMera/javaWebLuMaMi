package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.enums.EstadoCivil;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("testMB")
@SessionScoped()
public class TestMB implements Serializable{   //testMB
    private String nombre="";
    private String apellido="";
    private String direccion="";
    private EstadoCivil estadoCivil=EstadoCivil.CASADO;
    private String mensaje="";

    public void save(){
        try {
            nombre="";
            apellido="";
            direccion="";
            estadoCivil=EstadoCivil.CASADO;
            mensaje="Se guardo el registro";
        } catch (Exception e) {
            mensaje="No se pudo guardar el registro";
        }
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public EstadoCivil getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(EstadoCivil estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    
}
