package ar.com.eduit.curso.java.repositories.list;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{
    private List<Cliente>list;
    
    public ClienteRepository(){
        list=new ArrayList();
    }
    
    @Override
    public void save(Cliente cliente) {
        list.add(cliente);
    }

    @Override
    public void remove(Cliente cliente) {
        list.remove(cliente);
    }

    @Override
    public List<Cliente> getAll() {
        return list;
    }
    
}
