package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.enums.EstadoCivil;
import java.util.List;
import javax.inject.Named;

@Named()
public class EstadoCivilMB {    //estadoCivilMB
    public List<EstadoCivil>getEstados(){
        return List.of(EstadoCivil.values());
    }
}
