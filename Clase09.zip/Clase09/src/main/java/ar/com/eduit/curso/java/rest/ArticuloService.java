package ar.com.eduit.curso.java.rest;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/articulos/v1")
public class ArticuloService {
    private I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes Activo!";
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("save")
    public String save(@QueryParam("descripcion") String descripcion, 
                       @QueryParam("precio") double precio, 
                       @QueryParam("stock") int stock){
        Articulo articulo=new Articulo(descripcion, precio, stock);
        ar.save(articulo);
        return articulo.getId()+"";
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("remove")
    public String remove(@QueryParam("id")int id){
        try {
            ar.remove(ar.getById(id));
            return "true";
        } catch (Exception e) {
            return "false";
        }
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("all")
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("likeDescripcion")
    public String getLikeDescripcion(@QueryParam("descripcion") String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("byId")
    public String byId(@QueryParam("id") int id){
        return new Gson().toJson(ar.getById(id));
    }
    
}
