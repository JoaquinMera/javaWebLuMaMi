package ar.com.eduit.curso.java.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/testRS")
public class TestRS {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Hola Mundo Rest";
    }
    
    @GET
    @Path("/info2")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "<h1>Servicio 2</h1>";
    }
    
    @GET
    @Path("/saludo")
    @Produces(MediaType.TEXT_HTML)
    public String saludo(@QueryParam("nombre") String nombre){
        return "<h1>Hola "+nombre+"</h1>";
    }
}
