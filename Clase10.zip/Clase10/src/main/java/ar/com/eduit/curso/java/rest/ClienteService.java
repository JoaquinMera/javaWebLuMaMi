package ar.com.eduit.curso.java.rest;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
import ar.com.eduit.curso.java.repositories.list.ClienteRepositoryFactory;
import com.google.gson.Gson;
import java.util.List;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/clientes/v1")
public class ClienteService {
    //private I_ClienteRepository cr=ClienteRepositoryFactory.getClienteRepository();
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes v1 Activo";
    }
    
    @GET
    @Path("save")
    @Produces(MediaType.TEXT_PLAIN)
    public String save(
            @QueryParam("nombre")   String nombre, 
            @QueryParam("apellido") String apellido, 
            @QueryParam("edad")     int edad
    ){
        Cliente cliente=new Cliente(nombre, apellido, edad);
        cr.save(cliente);
        return cliente.getId()+"";
    }
    
    @GET
    @Path("remove")
    @Produces(MediaType.TEXT_PLAIN)
    public String remove(@QueryParam("id") int id){
        cr.remove(cr.getById(id));
        return "true";
    }
    
    @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        //List<Cliente>list=cr.getAll();
        //Gson gson=new Gson();
        //return gson.toJson(list);
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Path("likeApellido")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeDescripcion(@QueryParam("apellido") String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }
    
}
