package ar.com.eduit.curso.java.rest;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("calc")
public class Calculadora {
    
    private boolean login=false;
    private String user="";
    
    @POST
    @Produces(MediaType.TEXT_PLAIN)
    public String login(@QueryParam("user") String user, @QueryParam("pass") String pass){
        if(user.equals("admin") && pass.equals("123")){
            login=true;
            this.user=user;
            return "true";
        }else{
            return "false";
        }
        
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String sumar(@QueryParam("nro1")int n1, @QueryParam("nro2")int n2){
        if(login){
            return (n1+n2)+"";
        } else {
            return "false";
        }
    }
}
