/*
    ElephantSQL.com

Server:	motty.db.elephantsql.com

User & Default database: mswxlvsm

Password: KIJ8n6De_4V0VHGnWO4vH3cMh-yALdz3

URL: jdbc:postgresql://motty.db.elephantsql.com/mswxlvsm

*/

-- drop database if exists javaWeb;
-- create database javaWeb;
-- use javaWeb;
drop table if exists clientes;
drop table if exists articulos;

create table clientes(
    id serial primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int not null
);

alter table clientes 
    add constraint CK_clientes_edad
    check (edad >=18 and edad <=120);

create table articulos(
    id serial primary key,
    descripcion varchar(20) not null,
    precio float8 not null,
    stock int not null
);

alter table articulos
    add constraint CK_articulos_precio
    check (precio > 0);

alter table articulos
    add constraint CK_articulos_stock
    check (stock > 0);

select * from clientes;

insert into articulos (descripcion,precio,stock) values 
    ('Monitor 18',45000,40),
    ('Teclado usb',2450,30),
    ('Mouse opt',4560,60),
    ('Parlante USB',7890,70),
    ('Impresora 3d',90000,10);

select * from articulos;