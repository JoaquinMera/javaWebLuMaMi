package ar.com.eduit.curso.java.rest;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/testRS")
public class TestRS {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Hola Mundo Rest";
    }
    
    @GET
    @Path("/info2")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "<h1>Servicio 2</h1>";
    }
    
    @GET
    @Path("/saludo")
    @Produces(MediaType.TEXT_HTML)
    public String saludo(@QueryParam("nombre") String nombre){
        return "<h1>Hola "+nombre+"</h1>";
    }
}
