package ar.com.eduit.curso.java.rest;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("calc")
public class Calculadora {
    
    private boolean login=false;
    private String user="";
    
    @POST
    @Produces(MediaType.TEXT_PLAIN)
    public String login(@QueryParam("user") String user, @QueryParam("pass") String pass){
        if(user.equals("admin") && pass.equals("123")){
            login=true;
            this.user=user;
            return "true";
        }else{
            return "false";
        }
        
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String sumar(@QueryParam("nro1")int n1, @QueryParam("nro2")int n2){
        if(login){
            return (n1+n2)+"";
        } else {
            return "false";
        }
    }
}
