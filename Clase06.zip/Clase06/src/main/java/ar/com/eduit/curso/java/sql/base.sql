drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
create table clientes(
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int not null
);

alter table clientes 
    add constraint CK_clientes_edad
    check (edad >=18 and edad <=120);

create table articulos(
    id int auto_increment primary key,
    descripcion varchar(20) not null,
    precio double not null,
    stock int not null
);

alter table articulos
    add constraint CK_articulos_precio
    check (precio > 0);

alter table articulos
    add constraint CK_articulos_stock
    check (stock > 0);
