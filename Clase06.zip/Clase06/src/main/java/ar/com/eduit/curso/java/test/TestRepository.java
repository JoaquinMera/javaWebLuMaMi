package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
//import ar.com.eduit.curso.java.repositories.list.ClienteRepository;

public class TestRepository {
    public static void main(String[] args) {
        //I_ClienteRepository cr=new ClienteRepository();
        I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
        cr.save(new Cliente(1,"Ana","Perez",22));
        cr.save(new Cliente(2,"Juan","Celo",33));
        cr.save(new Cliente(3,"Mario","Mendez",44));
        cr.save(new Cliente(4,"Laura","Lopez",55));
        //cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        //System.out.println(cr.getById(2));
        System.out.println("****************************************************");
        //cr.getLikeApellido("o").forEach(System.out::println);
        
    }
}
