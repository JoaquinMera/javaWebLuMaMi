package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
//import ar.com.eduit.curso.java.repositories.list.ClienteRepository;

public class TestRepository {
    public static void main(String[] args) {
        System.out.println("-- Clientes --");
        //I_ClienteRepository cr=new ClienteRepository();
        I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
        cr.save(new Cliente(1,"Ana","Perez",22));
        cr.save(new Cliente(2,"Juan","Celo",33));
        cr.save(new Cliente(3,"Mario","Mendez",44));
        cr.save(new Cliente(4,"Laura","Lopez",55));
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println(cr.getById(2));
        System.out.println("****************************************************");
        cr.getLikeApellido("o").forEach(System.out::println);
        
        System.out.println("****************************************************");
        System.out.println("-- Articulos --");
        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        ar.save(new Articulo("Termo Mate",32,5));
        ar.save(new Articulo("Platos 6u",43,5));
        ar.save(new Articulo("Vasos 6u",45,6));
        ar.save(new Articulo("Tenedores 6u",56,7));
        
        ar.remove(ar.getById(8));
        
        ar.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        ar.getLikeDescripcion("te").forEach(System.out::println);
        
        
    }
}
