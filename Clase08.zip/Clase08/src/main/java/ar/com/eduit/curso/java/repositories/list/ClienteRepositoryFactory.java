package ar.com.eduit.curso.java.repositories.list;

import ar.com.eduit.curso.java.entities.Cliente;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepositoryFactory {
    private static ClienteRepository cr=new ClienteRepository();
    private ClienteRepositoryFactory(){}
    public static ClienteRepository getClienteRepository(){
        return cr;
    }
}
