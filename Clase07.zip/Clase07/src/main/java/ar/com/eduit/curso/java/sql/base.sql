drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
create table clientes(
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int not null
);

alter table clientes 
    add constraint CK_clientes_edad
    check (edad >=18 and edad <=120);

create table articulos(
    id int auto_increment primary key,
    descripcion varchar(20) not null,
    precio double not null,
    stock int not null
);

alter table articulos
    add constraint CK_articulos_precio
    check (precio > 0);

alter table articulos
    add constraint CK_articulos_stock
    check (stock > 0);

select * from clientes;

insert into articulos (descripcion,precio,stock) values 
    ('Monitor 18',45000,40),
    ('Teclado usb',2450,30),
    ('Mouse opt',4560,60),
    ('Parlante USB',7890,70),
    ('Impresora 3d',90000,10);

select * from articulos;