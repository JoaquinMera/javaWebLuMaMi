package ar.com.eduit.curso.java.repositories.interfaces;

import ar.com.eduit.curso.java.entities.Articulo;
import java.util.List;

public interface I_ArticuloRepository {
    List<Articulo>getAll();
}
