package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;


@Named()
@RequestScoped
public class ArticuloMB {
    I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    public List<Articulo>getAll(){
        return ar.getAll();
    }
}
