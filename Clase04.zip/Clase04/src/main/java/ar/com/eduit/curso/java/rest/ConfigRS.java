package ar.com.eduit.curso.java.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/webresources")
public class ConfigRS extends Application{

}
