package ar.com.eduit.curso.java.repositories.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{

    String urlServer;

    public ArticuloRepository(String urlServer) {
        this.urlServer = urlServer;
    }
    
    @Override
    public void save(Articulo articulo) {
        if(articulo==null) return;
        String url=urlServer+"/articulos/v1/save?descripcion="+articulo.getDescripcion()
                +"&precio="+articulo.getPrecio()+"&stock="+articulo.getStock();
        try{
            articulo.setId(Integer.parseInt(UtilHTTP.responseBody(url)));
        }catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void remove(Articulo articulo) {
        if(articulo==null) return;
        String url=urlServer+"/articulos/v1/remove?id="+articulo.getId();
        try {
            UtilHTTP.responseBody(url);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Articulo> getAll() {
        String url=urlServer+"/articulos/v1/all";
        Type listType = new TypeToken<List<Articulo>>(){}.getType();
        try{
            List<Articulo> list=new Gson().fromJson(UtilHTTP.responseBody(url),listType);
            return list;
        }catch(Exception e){
            System.out.println(e);
            return new ArrayList();
        }
    }
    
}
