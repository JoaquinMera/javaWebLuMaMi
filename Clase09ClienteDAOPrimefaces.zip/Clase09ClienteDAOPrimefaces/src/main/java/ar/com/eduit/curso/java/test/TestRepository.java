package ar.com.eduit.curso.java.test;


import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.rest.ArticuloRepository;
import ar.com.eduit.curso.java.repositories.rest.ClienteRepository;

//import ar.com.eduit.curso.java.repositories.list.ClienteRepository;

public class TestRepository {
    public static void main(String[] args) {
        System.out.println("-- Clientes --");
        //I_ClienteRepository cr=new ClienteRepository();
        //I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
        
        String urlServer="http://localhost:8082/Server/webresources";
        I_ClienteRepository cr=new ClienteRepository(urlServer);
        
        Cliente c1=new Cliente("Ana","Perez",22);
        Cliente c2=new Cliente("Juan","Celo",33);
        Cliente c3=new Cliente("Mario","Mendez",44);
        Cliente c4=new Cliente("Laura","Lopez",55);
        
        cr.save(c1);
        cr.save(c2);
        cr.save(c3);
        cr.save(c4);
        
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
        
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        System.out.println(cr.getById(2));
        System.out.println("****************************************************");
        cr.getLikeApellido("o").forEach(System.out::println);
        
        
        
        System.out.println("****************************************************");
        System.out.println("-- Articulos --");
        //I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        I_ArticuloRepository ar=new ArticuloRepository(urlServer);
        
        ar.save(new Articulo("Termo_Mate",32,5));
        ar.save(new Articulo("Platos_6u",43,5));
        ar.save(new Articulo("Vasos_6u",45,6));
        ar.save(new Articulo("Tenedores_6u",56,7));
        
        ar.remove(ar.getById(8));
        
        ar.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        ar.getLikeDescripcion("te").forEach(System.out::println);
        
        
    }
}
