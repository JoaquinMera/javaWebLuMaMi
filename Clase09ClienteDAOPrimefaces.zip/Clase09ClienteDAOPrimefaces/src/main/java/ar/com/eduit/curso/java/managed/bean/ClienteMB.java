package ar.com.eduit.curso.java.managed.bean;


import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.rest.ClienteRepository;

import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named("clienteMB")
@RequestScoped()
public class ClienteMB implements Serializable{
    private Cliente cliente=new Cliente();
    private String mensaje="";
    private String buscarApellido="";
    //private I_ClienteRepository cr=ClienteRepositoryFactory.getClienteRepository();
    private I_ClienteRepository cr=new ClienteRepository("http://localhost:8082/Server/webresources");
    
    public void save(){
        try {
            cr.save(cliente);
            mensaje="Se guardo el cliente id: "+cliente.getId();
            addMessage(FacesMessage.SEVERITY_INFO, "Info Message", mensaje);
            cliente=new Cliente();
        } catch (Exception e) {
            mensaje="No se pudo guardar el cliente!";
            //addMessage(FacesMessage.SEVERITY_ERROR, "Error Message",  mensaje);
        }
    }
    
    public void addMessage(FacesMessage.Severity severity, String summary, String detail) {
        FacesContext.getCurrentInstance().
                addMessage(null, new FacesMessage(severity, summary, detail));
    }
        
    public List<Cliente>getAll(){
        return cr.getAll();
    }
    
    public List<Cliente>getLikeApellido(){
        return cr.getLikeApellido(buscarApellido);
    }
    
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getBuscarApellido() {
        return buscarApellido;
    }

    public void setBuscarApellido(String buscarApellido) {
        this.buscarApellido = buscarApellido;
    }
    
}
