package ar.com.eduit.curso.java.repositories.rest;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

import java.util.ArrayList;
import java.util.List;


public class ClienteRepository implements I_ClienteRepository{
    
    private String urlServer;

    public ClienteRepository(String urlServer) {
        this.urlServer = urlServer;
    }

    @Override
    public void save(Cliente cliente) {
        if (cliente==null) return;
        String url=urlServer+"/clientes/v1/save?nombre="+cliente.getNombre()
                +"&apellido="+cliente.getApellido()+"&edad="+cliente.getEdad();
        try{
            cliente.setId(Integer.parseInt(UtilHTTP.responseBody(url)));
        }catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void remove(Cliente cliente) {
        if (cliente==null) return;
        String url=urlServer+"/clientes/v1/remove?id="+cliente.getId();
        try {
            UtilHTTP.responseBody(url);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Cliente> getAll() {
        String url=urlServer+"/clientes/v1/all";
        Type listType = new TypeToken<List<Cliente>>(){}.getType();
        try{
            List<Cliente> list=new Gson().fromJson(UtilHTTP.responseBody(url),listType);
            return list;
        }catch(Exception e){
            System.out.println(e);
            return new ArrayList();
        }
    }
    
}
