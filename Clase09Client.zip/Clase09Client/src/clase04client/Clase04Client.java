package clase04client;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class Clase04Client {
    public static void main(String[] args) throws Exception{
        // Cliente HTTP
        //System.out.println(responseBody("https://www.google.com.ar/"));
        //System.out.println(responseBody("http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano%20162"));
        //System.out.println(responseBody("https://ws.smn.gob.ar/map_items/weather"));
        
        
        String urlServer="http://localhost:8082/Server/webresources";
        
        System.out.println("****************************************************");
        System.out.println("-- Método info Cliente");
        System.out.println(responseBody(urlServer+"/clientes/v1"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método save Cliente");
        System.out.println(responseBody(urlServer+"/clientes/v1/save?nombre=Lorena&apellido=Casco&edad=38"));
        System.out.println(responseBody(urlServer+"/clientes/v1/save?nombre=Mario&apellido=Perez&edad=23"));
        System.out.println(responseBody(urlServer+"/clientes/v1/save?nombre=Susana&apellido=Tucci&edad=25"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método all Cliente");
        System.out.println(responseBody(urlServer+"/clientes/v1/all"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método likeApellido Cliente");
        System.out.println(responseBody(urlServer+"/clientes/v1/likeApellido?apellido=ca"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- List<Cliente> --");
        Type listType = new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente> list=new Gson().fromJson(responseBody(urlServer+"/clientes/v1/all"),listType);
        list.forEach(System.out::println);
        
        
        // ARTICULOS
        
        System.out.println("****************************************************");
        System.out.println("****************************************************");
        System.out.println("****************************************************");
        System.out.println("****************************************************");

        
                
        System.out.println("****************************************************");
        System.out.println("-- Método info Server");
        System.out.println(responseBody(urlServer));
        System.out.println("****************************************************");
        
        
        System.out.println("****************************************************");
        System.out.println("-- Método info Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1"));
        System.out.println("****************************************************");
        
        
        System.out.println("****************************************************");
        System.out.println("-- Método save Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/save?descripcion=Shampoo&precio=230&stock=90"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método save Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/save?descripcion=Jabon&precio=210&stock=190"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método save Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/save?descripcion=Enjuague&precio=230&stock=90"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método remove Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/remove?id=2"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método all Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/all"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método likeDescripcion Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/likeDescripcion?descripcion=ja"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Método byId Articulos");
        System.out.println(responseBody(urlServer+"/articulos/v1/byId?id=3"));
        System.out.println("****************************************************");
        
        
        System.out.println("****************************************************");
        System.out.println("-- List<Articulo> --");
        try{
            listType = new TypeToken<List<Articulo>>(){}.getType();
            List<Articulo> list2=new Gson().fromJson(responseBody(urlServer+"/articulos/v1/all"),listType);
            list2.forEach(System.out::println);
        }catch(Exception e){
            System.out.println(e);
        }
    
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32m"+"Status: "+response.statusCode());         //verde
        }else{
            System.out.println("\033[31m"+"Status: "+response.statusCode());         //rojo
        }
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
    
     private static String session(String url, String user, String pass) {
        //create the http client
        // https://mkyong.com/java/how-to-send-http-request-getpost-in-java/
        String resp = "";
        try {

            HttpURLConnection httpClient = (HttpURLConnection) new URL(url).openConnection();

            //add reuqest header
            httpClient.setRequestMethod("POST");
            httpClient.setRequestProperty("User-Agent", "Mozilla/5.0");
            httpClient.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            String urlParameters = "user=" + user + "&pass=" + pass;

            // Send post request
            httpClient.setDoOutput(true);
            try (DataOutputStream wr = new DataOutputStream(httpClient.getOutputStream())) {
                wr.writeBytes(urlParameters);
                wr.flush();
            }

            int responseCode = httpClient.getResponseCode();
            System.out.println("\nSending 'POST' request to URL : " + url);
            System.out.println("Post parameters : " + urlParameters);
            System.out.println("Response Code : " + responseCode);

            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(httpClient.getInputStream()))) {

                String line;
                StringBuilder response = new StringBuilder();

                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                System.out.println("-----------------------------------------");
                System.out.println(response.toString());
                System.out.println("-----------------------------------------");
                resp = response.toString();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return resp;
    }
    
}
